# Waqti Live v1 (Gmail alerts)

This tiny app serves a landing page (email capture), a booking page with your final slot UI, and emails you + the guest using **Gmail** (via an App Password).

## Quick start (Windows)
1. Unzip the folder somewhere simple (e.g., `C:\waqti-live-v1`)
2. Double-click `run-waqti.bat`
3. Open http://localhost:3000  (landing) and http://localhost:3000/book (booking)

## Configure Gmail email sending
- Turn on **2-Step Verification** on your Gmail account
- Create an **App Password** (Google Account → Security → App Passwords)
- Copy `.env.example` to `.env` and fill:
  - `OWNER_EMAIL` = where notifications go
  - `GMAIL_USER` = your Gmail address
  - `GMAIL_APP_PASSWORD` = the 16-character app password

If you leave `.env` blank, emails will be **simulated** (logged in the console) but not sent.

## API endpoints
- `POST /api/subscribe` { email }
- `POST /api/book` { name, email, slotISO, location, notes }
- `GET /api/bookings` — view saved bookings

## Notes
- Bookings & signups are saved in `/data/*.json` locally.
- You can deploy this later to Railway/Render for a public link.
