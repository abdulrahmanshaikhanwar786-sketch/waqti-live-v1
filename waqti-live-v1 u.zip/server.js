import express from "express";
import bodyParser from "body-parser";
import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const OWNER_EMAIL = process.env.OWNER_EMAIL || process.env.GMAIL_USER;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files
app.use(express.static("public"));

// Simple json storage
const DB_PATH = path.join(process.cwd(), "data");
const BOOKINGS_FILE = path.join(DB_PATH, "bookings.json");
const SIGNUPS_FILE = path.join(DB_PATH, "signups.json");
if (!fs.existsSync(DB_PATH)) fs.mkdirSync(DB_PATH);
for (const f of [BOOKINGS_FILE, SIGNUPS_FILE]) { if (!fs.existsSync(f)) fs.writeFileSync(f, "[]"); }

// Mail transport (Gmail app password)
function makeTransport() {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_APP_PASSWORD;
  if (!user || !pass) return null;
  return nodemailer.createTransport({
    service: "gmail",
    auth: { user, pass }
  });
}
const transport = makeTransport();

// Email helper
async function sendMail({ to, subject, text, html }) {
  if (!transport) {
    console.log("[Mail disabled] Would send to", to, subject);
    return;
  }
  await transport.sendMail({
    from: `"Waqti" <${process.env.GMAIL_USER}>`,
    to, subject, text, html
  });
}

// API: email signups for landing page
app.post("/api/subscribe", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "email required" });
  const list = JSON.parse(fs.readFileSync(SIGNUPS_FILE, "utf8"));
  if (!list.includes(email)) list.push(email);
  fs.writeFileSync(SIGNUPS_FILE, JSON.stringify(list, null, 2));
  res.json({ ok: true });
});

// API: create a booking
app.post("/api/book", async (req, res) => {
  const { name, email, slotISO, location, notes } = req.body;
  if (!name || !email || !slotISO) return res.status(400).json({ error: "missing fields" });
  const booking = {
    id: Date.now().toString(36),
    name, email,
    slotISO,
    whenLocal: new Date(slotISO).toString(),
    location: location || "zoom",
    notes: notes || "",
    createdAt: new Date().toISOString()
  };
  // Save
  const list = JSON.parse(fs.readFileSync(BOOKINGS_FILE, "utf8"));
  list.push(booking);
  fs.writeFileSync(BOOKINGS_FILE, JSON.stringify(list, null, 2));

  // Email owner
  const subject = `[Waqti] New booking: ${booking.whenLocal}`;
  const ownerHtml = `<p><b>New booking</b></p>
    <p><b>Name:</b> ${name}<br><b>Email:</b> ${email}<br><b>When:</b> ${booking.whenLocal}<br>
    <b>Location:</b> ${booking.location}<br><b>Notes:</b> ${booking.notes}</p>`;
  await sendMail({ to: OWNER_EMAIL, subject, text: subject, html: ownerHtml }).catch(e => console.error(e));

  // Email guest
  const guestHtml = `<p>Hi ${name}, your meeting is confirmed for <b>${booking.whenLocal}</b> via <b>${booking.location}</b>.</p><p>Thanks,<br>Waqti</p>`;
  await sendMail({ to: email, subject: "Your Waqti booking is confirmed", text: "Booked", html: guestHtml }).catch(e => console.error(e));

  res.json({ ok: true, booking });
});

app.get("/api/bookings", (_req, res) => {
  const list = JSON.parse(fs.readFileSync(BOOKINGS_FILE, "utf8"));
  res.json({ bookings: list });
});

app.listen(PORT, () => {
  console.log(`Waqti Live v1 running on http://localhost:${PORT}`);
});
